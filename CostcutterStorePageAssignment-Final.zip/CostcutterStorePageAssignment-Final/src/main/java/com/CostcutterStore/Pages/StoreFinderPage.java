package com.CostcutterStore.Pages;

import java.text.NumberFormat;
import java.util.List;
import java.util.logging.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import Utils.TestBase;
import org.openqa.selenium.support.ByIdOrName;
import org.openqa.selenium.By;

//// In this class, WebElements objects & methods for "https://www.costcutter.co.uk/location-finder/results" page are created
public class StoreFinderPage extends TestBase {

	private static final String Driver = null;
	
	@FindBy(xpath="//*[@id=\"totals\"]/div/h3")
	public static WebElement numberofstores;
	
	public  int getnumberofstorelocatorsvalidinputs(){
	String count=numberofstores.getText();
	String[] str1=count.split(" ");
	int num=Integer.parseInt(str1[0]);
    return(num);
   
    	}

	
		public  int getnumberofstorelocatorsinvalidinputs(){
		String count=numberofstores.getText();
		String[] str2=count.split(" ");
		int num1=Integer.parseInt(str2[0]);
	    return(num1);
		}
	
	
	
	
	
}






//}
