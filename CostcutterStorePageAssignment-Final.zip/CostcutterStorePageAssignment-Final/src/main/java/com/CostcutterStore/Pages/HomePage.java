package com.CostcutterStore.Pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;

// In this class, WebElements objects & methods for "https://www.costcutter.co.uk/location-finder/" page are created
import org.openqa.selenium.support.FindBy;

import Utils.TestBase;

public class HomePage extends TestBase {
	
	@FindBy(xpath="//*[@id=\"findOptions\"]/div[1]/form/fieldset/button")
    public static WebElement findmystorebutton;
	
	@FindBy(xpath="//*[@id=\"findOptions\"]/div[2]/a")
	public static WebElement findbylocateme;
	
	@FindBy(name="searchLocation")
	public static WebElement storesearchlocationtextbox;
	
	
	public void searchByCity(String location) {
		storesearchlocationtextbox.sendKeys(location);
		findmystorebutton.click();
		
	}

    public void searchByCustomerLocation() {
    	
    	findbylocateme.click();
    	
    }
	
    public  int CCStorePage(){
	     
		//driver.get("https://www.costcutter.co.uk/");
		String url = driver.getCurrentUrl();
		 int num3;
		if(url.equals("https://www.costcutter.co.uk/location-finder/")) 
	      num3=1;
		else
	      num3=0;
		 return(num3);
		}


}
