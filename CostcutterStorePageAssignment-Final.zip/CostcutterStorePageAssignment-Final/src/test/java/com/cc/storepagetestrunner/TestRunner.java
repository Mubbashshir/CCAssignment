/**
 * 
 */
package com.cc.storepagetestrunner;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * @Mubbashshir Mohiuddin
 * This class is used to execute the code in storepageteststeps using the Gherkin steps in feature file i.e.CostcutterStorePage.feature
 */
@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\User\\eclipse-workspace\\CostcutterStorePageAssignment-Final\\src\\test\\resources\\features",
                 glue = {"com.cc.storepageteststeps"},
plugin={ "json:target/cucumber.json",
"html:target/site/cucumber-pretty"})
public class TestRunner {
}


